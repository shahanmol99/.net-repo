﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CustomerLib.Service;
using CustomerLib.Model;
using CustomerApp.Models;

namespace CustomerApp.Controllers
{
    public class CustomerController : Controller
    {
        ICustomerService _service;

        public CustomerController(ICustomerService service)
        {
            _service = service;
        }

        // GET: Customer
        public ActionResult Index()
        {
            List<Customer> customers = _service.GetCustomers();
            return View(customers);
        }

        public ActionResult Add()
        {
            return View(new AddViewModel());
        }

        [HttpPost]
        public ActionResult Add(AddViewModel vm)
        {
            if(!ModelState.IsValid)
            {
                return View(vm);
            }
            _service.AddCustomer(new Customer { ID = Guid.NewGuid().ToString(), Name = vm.Name, Location = vm.Location });
            return RedirectToAction("Index");
        }

        public ActionResult Update(Customer customer)
        {
            return View(new UpdateViewModel { ID = customer.ID, Name = customer.Name, Location = customer.Location });
        }

        [HttpPost]
        public ActionResult Update(UpdateViewModel vm)
        {
            if (!ModelState.IsValid)
            {
                return View(vm);
            }
            _service.UpdateCustomerDetails(new Customer { ID = vm.ID, Name = vm.Name, Location = vm.Location });
            return RedirectToAction("Index");
        }


        public ActionResult Delete(Customer customer)
        {
            _service.DeleteCustomer(customer);
            return RedirectToAction("Index");
        }
    }
}