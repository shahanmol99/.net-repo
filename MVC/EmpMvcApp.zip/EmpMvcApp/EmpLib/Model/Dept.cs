﻿
namespace EmpLib.Model
{
    public class Dept
    {
        public int DeptNo { get; set; }

        public string DName { get; set; }

        public string Location { get; set; }
    }
}
