﻿
namespace EmpLib.Model
{
    public class Employee
    {
        public int EmpNo { get; set; }
        public string EName { get; set; }
        public string Job { get; set; }
        public string MgrNo { get; set; }
        public string HireDate { get; set; }
        public double Salary { get; set; }
        public string Commission { get; set; }
        public int DeptNo { get; set; }
    }
}
