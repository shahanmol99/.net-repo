﻿using EmpLib.Model;
using System.Collections.Generic;

namespace EmpMvcApp.Models
{
    public class EmpAndDeptViewModel
    {
        public List<Dept> dept { get; set; }
        public List<Employee> emps { get; set; }

    }
}