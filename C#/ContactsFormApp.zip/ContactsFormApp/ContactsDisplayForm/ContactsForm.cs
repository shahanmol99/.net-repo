﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ContactsLibrary.Data;
using ContactsLibrary.Model;

namespace ContactsDisplayForm
{
    public partial class ContactsForm : Form
    {
        public ContactsForm()
        {
            InitializeComponent();
        }

        private void DisplayContacts(object sender, EventArgs e)
        {
            DataAccess contactDB = new ContactsSqlDB();
            List<Contact> contacts = contactDB.GetContacts();

            this.dataGridView1.DataSource = contacts;
        }

        private void addContact_Click(object sender, EventArgs e)
        {
            new AddContactForm().Show();
        }

        private void showAddress_Click(object sender, EventArgs e)
        {
            DataAccess contactDB = new ContactsSqlDB();
            List<ContactsWithAddress> contacts = contactDB.GetContactAndAddress();

            this.dataGridView1.DataSource = contacts;
        }
    }
}
