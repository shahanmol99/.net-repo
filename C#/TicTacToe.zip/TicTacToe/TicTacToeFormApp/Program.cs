﻿using System.Windows.Forms;

namespace TicTacToeFormApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Application.Run(new TicTacToeWelcome());
        }
    }
}
